package com.panasonic.iotair.config;

import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Collection;

/**
 * @author tao
 * @version 1.0
 * @date 9/4/2020 上午10:23
 */
@Component
public class AutoPermissionEvaluator implements PermissionEvaluator {
    @Override
    public boolean hasPermission(Authentication authentication, Object o, Object o1) {
        if (o.equals("user")) {
            return hasPermissionUser(authentication,o1);
        }
        return false;
    }

    @Override
    public boolean hasPermission(Authentication authentication, Serializable serializable, String s, Object o) {
        return false;
    }


    /**
     * 简单的字符串比较，相同则认为有权限
     */

    private boolean hasPermissionUser(Authentication authentication, Object permission) {
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        for (GrantedAuthority authority : authorities) {
            if (authority.getAuthority().endsWith(permission.toString())) {
                return true;
            }
        }
        return false;
    }
}
