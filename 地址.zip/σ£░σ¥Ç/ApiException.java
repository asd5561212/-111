package com.panasonic.iotair.common;

/**
 * @author tao
 * @version 1.0
 * @date 26/3/2020 上午11:11
 */
public class ApiException extends RuntimeException{

}
