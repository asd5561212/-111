package com.panasonic.iotair.common;

/**
 * @author tao
 * @version 1.0
 * @date 2019/10/15 15:34
 */
public class Constant {

    public static final String DEFAULT_USER_PASSWORD  = "123";

    public static final String DEFAULT_ROLE_PRE  = "ROLE_";

    public static final String DEFAULT_USER_STATUS  = "1";

    public static final String LOCK_USER_STATUS  = "0";

    // 设备型号LD5C（新风）的表名
    public static final String AIR_FRESH_LD5C = "data_ld5c";
    // 设备型号LD5C（新风）的表名
    public static final String AIR_FRESH_LD5CX = "data_ld5cx";
    // 设备型号ERV（新风）的表名
    public static final String AIR_FRESH_ERV = "data_erv";
    // 设备型号MIDERV（新风）的表名
    public static final String AIR_FRESH_MIDERV = "data_miderv";
    // 设备型号floorplacederv（新风）的表名
    public static final String AIR_FRESH_FLOORPLACEDERV = "data_floorplacederv";
    // 设备型号needsAp（新风）的表名
    public static final String AIR_FRESH_NEEDSAP = "data_needsap";
    // 设备型号DCERV（新风）的表名
    public static final String AIR_FRESH_DCERV = "data_dcerv";
    // 设备型号PXP60C（空净）的表名
    public static final String AIR_CLEANER_PXP60C = "data_pxp60c";
    // 设备型号VXR110C（空净）的表名
    public static final String AIR_CLEANER_VXR110C = "data_vxr110c";
    // 设备型号FV54BA1C（浴霸）的表名
    public static final String BATH_HEATER_FV54BA1C = "data_fv54ba1c";
    // 设备型号FVRB20VL1（浴霸）的表名
    public static final String BATH_HEATER_FVRB20VL1 = "data_fvrb20vl1";
    // 频率统计记录的表名
    public static final String STA_FREQUENCY = "sta_frequency";
    // 使用时长统计记录的表名
    public static final String STA_DURATION = "sta_duration";
    // 使用定时功能统计记录的表名
    public static final String STA_TIMING = "sta_timing";
    // 传感器统计记录的表名
    public static final String STA_SENSOR = "sta_sensor";
    // 故障统计记录的表名
    public static final String STA_ERROR = "sta_error";
    // APP联动统计记录的表名
    public static final String STA_APPLINKAGE = "sta_applinkage";
    // 滤网统计记录的表名
    public static final String STA_FILTER = "sta_filter";
    // 使用时间点统计记录的表名
    public static final String STA_USETIME = "sta_usetime";
    // 频率统计运行状态
    public static final String FREQUENCY_RUNNINGMODE = "runningMode";
    // 频率统计风挡
    public static final String FREQUENCY_AIRVOLUME = "airVolume";
    // 频率统计假期模式
    public static final String FREQUENCY_HOLIDAYMODE = "holidayMode";
    // 频率统计nanoe
    public static final String FREQUENCY_NANOE = "nanoe";
    // 频率统计气体有无
    public static final String FREQUENCY_GASCHECKHAS = "gasCheckHas";
    // 频率统计照明
    public static final String FREQUENCY_LIGHTSET = "lightSet";

    // 设备型号FVRB20VL1（浴霸）取暖运转模式(遥控器控制)
    public static final long BATH_HEATER_FVRB20VL1_RUNNINGMODE_HEATING_RC = 21;
    // 设备型号FVRB20VL1（浴霸）换气强运转模式(遥控器控制)
    public static final long BATH_HEATER_FVRB20VL1_RUNNINGMODE_VENTILATION_STRONG_RC = 22;
    // 设备型号FVRB20VL1（浴霸）凉干燥强运转模式(遥控器控制)
    public static final long BATH_HEATER_FVRB20VL1_RUNNINGMODE_COOL_DRY_STRONG_RC = 24;
    // 设备型号FVRB20VL1（浴霸）热干燥强运转模式(遥控器控制)
    public static final long BATH_HEATER_FVRB20VL1_RUNNINGMODE_HOT_DRY_STRONG_RC = 26;

    // 设备型号FVRB20VL1（浴霸）取暖运转模式(app控制)
    public static final long BATH_HEATER_FVRB20VL1_RUNNINGMODE_HEATING_APP = 37;
    // 设备型号FVRB20VL1（浴霸）换气强运转模式(app控制)
    public static final long BATH_HEATER_FVRB20VL1_RUNNINGMODE_VENTILATION_STRONG_APP = 38;
    // 设备型号FVRB20VL1（浴霸）凉干燥强运转模式(app控制)
    public static final long BATH_HEATER_FVRB20VL1_RUNNINGMODE_COOL_DRY_STRONG_APP = 40;
    // 设备型号FVRB20VL1（浴霸）热干燥强运转模式(app控制)
    public static final long BATH_HEATER_FVRB20VL1_RUNNINGMODE_HOT_DRY_STRONG_APP = 42;
    // 设备型号FVRB20VL1（浴霸）照明(开)
    public static final long BATH_HEATER_FVRB20VL1_LIGHTSET_ON = 1;

    // 设备型号FV54BA1C（浴霸）一键智能1运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_ONETOUCH_STEP1_RC = 17;
    // 设备型号FV54BA1C（浴霸）一键智能2运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_ONETOUCH_STEP2_RC = 18;
    // 设备型号FV54BA1C（浴霸）一键智能3运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_ONETOUCH_STEP3_RC = 19;
    // 设备型号FV54BA1C（浴霸）一键智能4运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_ONETOUCH_STEP4_RC = 20;

    // 设备型号FV54BA1C（浴霸）取暖运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_HEATING_RC = 21;
    // 设备型号FV54BA1C（浴霸）换气强运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_VENTILATION_STRONG_RC = 22;
    // 设备型号FV54BA1C（浴霸）换气弱运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_VENTILATION_WEAK_RC = 23;
    // 设备型号FV54BA1C（浴霸）凉干燥强运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_COOL_DRY_STRONG_RC = 24;
    // 设备型号FV54BA1C（浴霸）凉干燥弱运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_COOL_DRY_WEAK_RC = 25;
    // 设备型号FV54BA1C（浴霸）热干燥强运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_HOT_DRY_STRONG_RC = 26;
    // 设备型号FV54BA1C（浴霸）热干燥弱运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_HOT_DRY_WEAK_RC = 27;
    // 设备型号FV54BA1C（浴霸）除菌运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_NANOE_RC = 29;

    // 设备型号FV54BA1C（浴霸）一键智能1运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_ONETOUCH_STEP1_APP = 33;
    // 设备型号FV54BA1C（浴霸）一键智能2运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_ONETOUCH_STEP2_APP = 34;
    // 设备型号FV54BA1C（浴霸）一键智能3运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_ONETOUCH_STEP3_APP = 35;
    // 设备型号FV54BA1C（浴霸）一键智能4运转模式(遥控器控制)
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_ONETOUCH_STEP4_APP = 36;

    // 设备型号FV54BA1C（浴霸）取暖运转模式（APP控制）
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_HEATING_APP = 37;
    // 设备型号FV54BA1C（浴霸）换气强运转模式（APP控制）
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_VENTILATION_STRONG_APP = 38;
    // 设备型号FV54BA1C（浴霸）换气弱运转模式（APP控制）
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_VENTILATION_WEAK_APP = 39;
    // 设备型号FV54BA1C（浴霸）凉干燥强运转模式（APP控制）
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_COOL_DRY_STRONG_APP = 40;
    // 设备型号FV54BA1C（浴霸）凉干燥弱运转模式（APP控制）
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_COOL_DRY_WEAK_APP = 41;
    // 设备型号FV54BA1C（浴霸）热干燥强运转模式（APP控制）
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_HOT_DRY_STRONG_APP = 42;
    // 设备型号FV54BA1C（浴霸）热干燥弱运转模式（APP控制）
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_HOT_DRY_WEAK_APP = 43;
    // 设备型号FV54BA1C（浴霸）24小时换气运转模式（APP控制）
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_24VENTILATION_APP = 44;
    // 设备型号FV54BA1C（浴霸）除菌运转模式（APP控制）
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_NANOE_APP = 45;

    // 设备型号FV54BA1C（浴霸）DIY取暖运转模式
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_DIY_HEATING = 53;
    // 设备型号FV54BA1C（浴霸）DIY换气强运转模式
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_DIY_VENTILATION_STRONG = 54;
    // 设备型号FV54BA1C（浴霸）DIY换气弱运转模式
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_DIY_VENTILATION_WEAK = 55;
    // 设备型号FV54BA1C（浴霸）DIY凉干燥强运转模式
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_DIY_COOL_DRY_STRONG = 56;
    // 设备型号FV54BA1C（浴霸）DIY凉干燥弱运转模式
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_DIY_COOL_DRY_WEAK = 57;
    // 设备型号FV54BA1C（浴霸）DIY热干燥强运转模式
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_DIY_HOT_DRY_STRONG = 58;
    // 设备型号FV54BA1C（浴霸）DIY热干燥弱运转模式
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_DIY_HOT_DRY_WEAK_ = 59;
    // 设备型号FV54BA1C（浴霸）DIY24小时换气运转模式
    public static final long BATH_HEATER_FV54BA1C_RUNNINGMODE_DIY_24VENTILATION = 60;
    // 设备型号FV54BA1C（浴霸）异味感知（有）
    public static final long BATH_HEATER_FV54BA1C_GASCHECKHAS_TRUE = 1;

    // 设备型号PXP60C（空净）风量Auto
    public static final long AIRCLEANER_PXP60C_AIRVOLUME_AUTO = 0;
    // 设备型号PXP60C（空净）风量Lo
    public static final long AIRCLEANER_PXP60C_AIRVOLUME_LO = 1;
    // 设备型号PXP60C（空净）风量Mid
    public static final long AIRCLEANER_PXP60C_AIRVOLUME_MID = 2;
    // 设备型号PXP60C（空净）风量Hi
    public static final long AIRCLEANER_PXP60C_AIRVOLUME_HI = 3;
    // 设备型号PXP60C（空净）NANOE开
    public static final long AIRCLEANER_PXP60C_NANOE_ON = 0;
    // 设备型号PXP60C（空净）NANOE关
    public static final long AIRCLEANER_PXP60C_NANOE_OFF = 1;
    // 设备型号PXP60C（空净）灰尘传感器敏感度低
    public static final long AIRCLEANER_PXP60C_SENSORSENSITIVITY_LO = 0;
    // 设备型号PXP60C（空净）灰尘传感器敏感度中
    public static final long AIRCLEANER_PXP60C_SENSORSENSITIVITY_MID = 1;
    // 设备型号PXP60C（空净）灰尘传感器敏感度高
    public static final long AIRCLEANER_PXP60C_SENSORSENSITIVITY_HI = 2;
    // 设备型号PXP60C（空净）照明亮
    public static final long AIRCLEANER_PXP60C_LED_BRIGHT = 1;
    // 设备型号PXP60C（空净）照明关
    public static final long AIRCLEANER_PXP60C_LED_OFF = 3;

    // 设备型号VXR110C（空净）风量LO
    public static final long AIRCLEANER_VXR110C_AIRVOLUME_LO = 1;
    // 设备型号VXR110C（空净）风量MID
    public static final long AIRCLEANER_VXR110C_AIRVOLUME_MID = 2;
    // 设备型号VXR110C（空净）风量HI
    public static final long AIRCLEANER_VXR110C_AIRVOLUME_HI = 3;
    // 设备型号VXR110C（空净）风量TURBO
    public static final long AIRCLEANER_VXR110C_AIRVOLUME_TURBO = 4;
    // 设备型号VXR110C（空净）加湿开
    public static final long AIRCLEANER_VXR110C_HUMIDIFICATION_ON = 1;
    // 设备型号VXR110C（空净）加湿开
    public static final long AIRCLEANER_VXR110C_HUMIDIFICATION_OFF = 0;
    // 设备型号VXR110C（空净）NANOE开
    public static final long AIRCLEANER_VXR110C_NANOE_ON = 0;
    // 设备型号VXR110C（空净）NANOE关
    public static final long AIRCLEANER_VXR110C_NANOE_OFF = 1;
    // 设备型号VXR110C（空净）childLock开
    public static final long AIRCLEANER_VXR110C_CHILDLOCK_ON = 1;
    // 设备型号VXR110C（空净）childLock关
    public static final long AIRCLEANER_VXR110C_CHILDLOCK_OFF = 0;
    // 设备型号VXR110C（空净）照明亮
    public static final long AIRCLEANER_VXR110C_LED_BRIGHT = 1;
    // 设备型号VXR110C（空净）照明暗
    public static final long AIRCLEANER_VXR110C_LED_DARK = 2;
    // 设备型号VXR110C（空净）照明关
    public static final long AIRCLEANER_VXR110C_LED_OFF = 3;
    // 设备型号VXR110C（空净）灰尘传感器敏感度低
    public static final long AIRCLEANER_VXR110C_DUSTSENSORSENSITIVITY_LO = 0;
    // 设备型号VXR110C（空净）灰尘传感器敏感度中
    public static final long AIRCLEANER_VXR110C_DUSTSENSORSENSITIVITY_MID = 1;
    // 设备型号VXR110C（空净）灰尘传感器敏感度高
    public static final long AIRCLEANER_VXR110C_DUSTSENSORSENSITIVITY_HI = 2;
    // 设备型号VXR110C（空净）气味传感器敏感度低
    public static final long AIRCLEANER_VXR110C_GASSENSORSENSITIVITY_LO = 0;
    // 设备型号VXR110C（空净）气味传感器敏感度中
    public static final long AIRCLEANER_VXR110C_GASSENSORSENSITIVITY_MID = 1;
    // 设备型号VXR110C（空净）气味传感器敏感度高
    public static final long AIRCLEANER_VXR110C_GASSENSORSENSITIVITY_HI = 2;

    // 设备型号NeedsAP（空净）风量Auto
    public static final long AIRCLEANER_NEEDSAP_AIRVO_AUTO = 0;
    // 设备型号NeedsAP（空净）风量LO
    public static final long AIRCLEANER_NEEDSAP_AIRVO_LO = 1;
    // 设备型号NeedsAP（空净）风量MID
    public static final long AIRCLEANER_NEEDSAP_AIRVO_MID = 2;
    // 设备型号NeedsAP（空净）风量HI
    public static final long AIRCLEANER_NEEDSAP_AIRVO_HI = 3;
    // 设备型号NeedsAP（空净）NANOE关
    public static final long AIRCLEANER_NEEDSAP_NANOE_ON = 1;
    // 设备型号NeedsAP（空净）NANOE开
    public static final long AIRCLEANER_NEEDSAP_NANOE_OFF = 0;
    // 设备型号NeedsAP（空净）childLock关
    public static final long AIRCLEANER_NEEDSAP_CHILDLOCK_ON = 1;
    // 设备型号NeedsAP（空净）childLock开
    public static final long AIRCLEANER_NEEDSAP_CHILDLOCK_OFF = 0;
    // 设备型号NeedsAP（空净）照明亮
    public static final long AIRCLEANER_NEEDSAP_LED_BRIGHT = 1;
    // 设备型号NeedsAP（空净）照明关
    public static final long AIRCLEANER_NEEDSAP_LED_OFF = 3;
    // 设备型号NeedsAP（空净）灰尘传感器敏感度低
    public static final long AIRCLEANER_NEEDSAP_DUST_LO = 0;
    // 设备型号NeedsAP（空净）灰尘传感器敏感度中
    public static final long AIRCLEANER_NEEDSAP_DUST_MID = 1;
    // 设备型号NeedsAP（空净）灰尘传感器敏感度高
    public static final long AIRCLEANER_NEEDSAP_DUST_HI = 2;
    // 设备型号NeedsAP（空净）气味传感器敏感度低
    public static final long AIRCLEANER_NEEDSAP_GAS_LO = 0;
    // 设备型号NeedsAP（空净）气味传感器敏感度中
    public static final long AIRCLEANER_NEEDSAP_GAS_MID = 1;
    // 设备型号NeedsAP（空净）气味传感器敏感度高
    public static final long AIRCLEANER_NEEDSAP_GAS_HI = 2;
    // 设备型号NeedsAP（空净）TVOC传感器敏感度低
    public static final long AIRCLEANER_NEEDSAP_SENSITVOC_LO = 0;
    // 设备型号NeedsAP（空净）TVOC传感器敏感度中
    public static final long AIRCLEANER_NEEDSAP_SENSITVOC_MID = 1;
    // 设备型号NeedsAP（空净）TVOC传感器敏感度高
    public static final long AIRCLEANER_NEEDSAP_SENSITVOC_HI = 2;

    public static final String USER_ROLE_MENU_TYPE_ONE = "1";

    public static final String USER_ROLE_MENU_TYPE_TWO = "2";

    public static final String USER_ROLE_MENU_TYPE_THREE = "3";

    public static final int EXCEL_PAGE_NUMBER = 1;

    public static final int EXCEL_PAGE_SIZE = 40000;

    public static final String AD_UPDATE_STATUS = "AD_UPDATE_STATUS";

    public static final String USER_REDIS_KEY = "REDIS_USER_KEY_";

    public static final String USER_REDIS_URL = "USER_REDIS_URL_";

}
