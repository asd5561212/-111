package com.panasonic.iotair.controller;

import com.panasonic.iotair.common.NIOClint;

/**
 * @author tao
 * @version 1.0
 * @date 7/4/2020 下午3:26
 */
public class NIOWeb {


    public static void main(String[] args) {
        NIOClint.client();
    }
}
