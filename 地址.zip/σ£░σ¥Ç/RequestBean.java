package com.panasonic.iotair.common;

import com.panasonic.iotair.bean.CurrentUser;

import java.io.Serializable;


/**
 * @author tao
 * @version 1.0
 * @date 23/3/2020 下午1:49
 */
public class RequestBean implements Serializable {

    private Object parameter;

    private CurrentUser currentUser;

    public RequestBean(CurrentUser user) {
        this.currentUser = user;
    }

    public void setParameter(Object parameter) {
        this.parameter = parameter;
    }


    public CurrentUser getCurrentUser() {
        return this.currentUser;
    }

    public Object getParameter() {
        return parameter;
    }
}
