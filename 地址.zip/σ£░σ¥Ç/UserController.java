package com.panasonic.iotair.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.panasonic.iotair.api.UserServiceApi;
import com.panasonic.iotair.bean.*;
import com.panasonic.iotair.common.*;
import com.panasonic.iotair.service.MenuService;
import com.panasonic.iotair.service.UserMessageService;
import com.panasonic.iotair.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liang on 2019/10/10.
 */
@RestController
@RequestMapping("/user")
public class UserController {

    private final static Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserMessageService userMessageService;

    @Autowired
    private UserService userService;

    @Autowired
    private MenuService menuService;

    @Reference
    private UserServiceApi userServiceApi;

    @RequestMapping("/info")
    public RespBean userRole() {
        User user = UserUtils.getCurrentUser();
        RespBean respBean = null;
        List<String> returnList = new ArrayList<String>();
        Map<String, Object> returnMap = new HashMap<String, Object>();
        if (user != null) {
            Map<String, Object> mapRoles = new HashMap<String, Object>();
            for (int i = 0; i < user.getRoles().size(); i++) {
                returnList.add(user.getRoles().get(i).getName());
            }
            returnMap.put("introduction", "I am a super administrator");
            returnMap.put("avatar", "/head.png");
            returnMap.put("name", user.getName());
            returnMap.put("roles", returnList);
            returnMap.put("roleType",user.getUserType());
            returnMap.put("forbidden",user.getUsername());
            respBean = RespBean.ok("成功获取用户角色！", returnMap);
        }
        userServiceApi.addCurrUser(RPCRequest.newInstance());
        return respBean;
    }

    /**
     * 第一次登陆用户修改自己密码
     *
     * @param user
     * @return
     */
    @RequestMapping(value = "/exit/password")
    public RespBean exitUserPassWord(UserVo user) {
        RespBean respBean = null;
        if (user == null || StringUtils.isEmpty(user.getUsername())
                || StringUtils.isEmpty(user.getNewPassWord())
                || StringUtils.isEmpty(user.getPassword())) {
            respBean = RespBean.error("用户名或密码不能为空", null, null);
            return respBean;
        } else {
            //  根据用户去数据库查询密码
            User userDetails = userService.queryUserByUsername(user.getUsername());
            if (userDetails == null) {
                respBean = RespBean.error("用户不存在", null, null);
                return respBean;
            }
            //  查询后和前端传过来的进行对比 正确修改 不正确 返回错误信息
            if (BCPEUtils.matches(user.getPassword(), userDetails.getPassword())) {
                // 修改密码
                User newUser = new User();
                newUser.setPassword(BCPEUtils.encode(user.getNewPassWord()));
                newUser.setId(userDetails.getId());
                userService.updateUser(newUser);
                respBean = RespBean.ok("密码修改成功");
                return respBean;
            } else {
                // 密码输入错误
                respBean = RespBean.error("密码不正确", null, null);
                return respBean;
            }
        }
    }

    /**
     * 添加用户
     *
     * @param
     * @return
     */
    @RequestMapping(value = "/add/user/role")
    @PreAuthorize("hasPermission('user','_1') or hasPermission('user','_2')")
    public RespBean addUserWithRole(@RequestBody RoleJson roleJson) {
        RespBean respBean = null;
        if (roleJson == null || CollectionUtils.isEmpty(roleJson.getRoutes())) {
            respBean = RespBean.error("添加用户或者菜单不能为空");
            return respBean;
        }
        //  用户名不能重复校验
        User user = userService.queryUserByUsername(roleJson.getKey());
        if (user != null) {
            respBean = RespBean.error("该用户已存在,请重新填写用户名");
            return respBean;
        }
        try {
            userMessageService.addUserRole(roleJson);
            respBean = RespBean.ok("添加用户成功");
        } catch (Exception e) {
            e.printStackTrace();
            respBean = RespBean.error("添加用户异常");
        }
        return respBean;
    }


    /**
     * 删除用户
     *
     * @param
     * @return
     */
    @RequestMapping(value = "/remove/user")
    public RespBean removeUserWithRole(@RequestBody RoleJson roleJson) {
        RespBean respBean = null;
        if (roleJson == null || StringUtils.isEmpty(roleJson.getId())) {
            respBean = RespBean.error("删除用户不能为空");
            return respBean;
        }
        try {
            userMessageService.removeUserByKey(roleJson);
            respBean = RespBean.ok("删除用户成功");
        } catch (Exception e) {
            e.printStackTrace();
            respBean = RespBean.error("删除用户异常");
        }
        return respBean;
    }


    /**
     * 用户管理管理员修改用户密码
     *
     * @param user
     * @return
     */
    @RequestMapping(value = "/admin/exit/password")
    public RespBean adminExitUserPassWord(@RequestBody UserVo user) {
        RespBean respBean = null;
        if (user == null || StringUtils.isEmpty(user.getUsername())
                || StringUtils.isEmpty(user.getNewPassWord())) {
            respBean = RespBean.error("用户名或密码不能为空", null, null);
            return respBean;
        } else {
            //  根据用户去数据库查询密码
            User userDetails = userService.queryUserByUsername(user.getUsername());
            if (userDetails == null) {
                respBean = RespBean.error("用户不存在", null, null);
                return respBean;
            }
            try {
                userMessageService.updateUserPasswordByAdmin(user);
                respBean = RespBean.ok("密码修改成功");
                return respBean;
            } catch (Exception e) {
                e.printStackTrace();
                respBean = RespBean.error("修改密码异常");
                return respBean;
            }
        }
    }


    /**
     * 编辑用户
     *
     * @param
     * @return
     */
    @RequestMapping(value = "/exit/user/role")
    @PreAuthorize("hasPermission('user','_1')")
    public RespBean exitUserWithRole(@RequestBody RoleJson roleJson) {
        RespBean respBean = null;
        if (roleJson == null || CollectionUtils.isEmpty(roleJson.getRoutes())) {
            respBean = RespBean.error("修改用户或者菜单不能为空");
            return respBean;
        }
        //  用户名不能重复校验除了自己以外
        User user = userMessageService.findUserByUsername(roleJson);
        if (user != null) {
            respBean = RespBean.error("该用户已存在,请重新填写用户名");
            return respBean;
        }
        try {
            userMessageService.updateUserRole(roleJson);
            respBean = RespBean.ok("修改用户成功");
        } catch (Exception e) {
            e.printStackTrace();
            respBean = RespBean.error("修改用户异常");
        }
        return respBean;
    }

//    /**
//     * 查询所有用户权限菜单
//     *
//     * @param
//     * @return
//     */
//    @RequestMapping("/getAllRolesMenu")
//    public RespBean getAllRolesMenu() {
//        return RespBean.ok(menuService.getAllRolesMenu());
//    }


    /**
     * 查询所有用户权限菜单根据条件
     *
     * @param
     * @return
     */
    @RequestMapping("/getAllRolesMenuByKey")
    public RespBean getAllRolesMenuByKey(@RequestBody UserVo user) {
        return RespBean.ok(menuService.getAllRolesMenuByKey(user));
    }

    /**
     * 查询菜单的所有权限
     *
     * @param
     * @return
     */
    @RequestMapping("/getMenuRoles")
    public RespBean getMenuRoles() {
        return RespBean.ok(menuService.getMenuRoles());
    }
}
