package com.panasonic.iotair.api;

import com.panasonic.iotair.common.RequestBean;

public interface UserServiceApi {

    public void addCurrUser(RequestBean request);

}
