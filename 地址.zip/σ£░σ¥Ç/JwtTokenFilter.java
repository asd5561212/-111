package com.panasonic.iotair.filter;

import com.panasonic.iotair.common.*;
import com.panasonic.iotair.config.UserRequestWrapper;
import com.panasonic.iotair.service.UserService;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class JwtTokenFilter extends OncePerRequestFilter {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private RedisUtil redisUtil;

    @Value("${pic.file.service.url}")
    private String serviceCsrfUrl;

    private static Integer times = 300;


    /**
     * 存放Token的Header Key
     */
    public static final String HEADER_STRING = "Authorization";

    public static final String HEADER_USER = "Forbidden";

    public static final String REFERER = "Referer";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
        String token = request.getHeader(HEADER_STRING);
        if (null != token) {
            if (token.startsWith("Bearer ")) {
                token = token.replace("Bearer ", "");
            }
            try {
                String username_password = jwtTokenUtil.getUsernameFromToken(token);
                String username = username_password.split(",")[0];
                if (checkUrlTimes(username, request)) {
                    jwtTokenUtil.returnTokenMsg(50020, "该时间段接口访问过于频繁", response);
                    return;
                }
                if (checkUserIp(username, request)) {
                    jwtTokenUtil.returnTokenMsg(50019, "异地登录退出", response);
                    return;
                }
                if (checkCurrUser(request, username)) {
                    jwtTokenUtil.returnTokenMsg(50016, "非法请求,当前用户已退出", response);
                    return;
                }
                if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                    UserDetails userDetails = this.userService.loadUserByUsername(username);
                    if (jwtTokenUtil.validateToken(token, userDetails)) {
                        UserUntil.setUser(userService.queryUserByUsername(username));
                        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                                userDetails, null, userDetails.getAuthorities());
                        authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(
                                request));
                        SecurityContextHolder.getContext().setAuthentication(authentication);
                    }
                }
            } catch (ExpiredJwtException e) {
                jwtTokenUtil.returnTokenMsg(50014, "Token已过期", response);
                return;
            } catch (UnsupportedJwtException e) {
                jwtTokenUtil.returnTokenMsg(50012, "Token格式错误", response);
                return;
            } catch (MalformedJwtException e) {
                jwtTokenUtil.returnTokenMsg(50012, "Token没有被正确构造", response);
                return;
            } catch (SignatureException e) {
                jwtTokenUtil.returnTokenMsg(50012, "签名失败", response);
                return;
            } catch (IllegalArgumentException e) {
                jwtTokenUtil.returnTokenMsg(50008, "非法参数异常", response);
                return;
            }
        }
        chain.doFilter(new UserRequestWrapper(request), response);
        return;
    }


    private boolean checkCurrUser(HttpServletRequest request, String username) {
        boolean status = true;
        String forbidden = request.getHeader(HEADER_USER);
        String currName = AESUtils.aesDecrypt(AESUtils.aesDecrypt(forbidden));
        if (username.equals(currName)) {
            status = false;
        }
        return status;
    }

    private boolean checkUserIp(String username, HttpServletRequest request) {
        boolean status = false;
        Object o = redisUtil.get(Constant.USER_REDIS_KEY + username);
        String ip = (String) o;
        if (!IPUtils.getIP(request).equals(ip)) {
            status = true;
        }
        return status;
    }

    private boolean checkUrlTimes(String username, HttpServletRequest request) {
        boolean status = false;
        if (!checkTime("2020-04-02 00:20:00", "2020-04-02 17:40:00")) {
            return status;
        }
        if (request.getRequestURI().contains("/query/put/advert")) {
            Object o = redisUtil.lGetIndex(Constant.USER_REDIS_URL + username, 0);
            if (o == null) {
                List<Object> value = new ArrayList<Object>();
                value.add(1);
                redisUtil.lSet(Constant.USER_REDIS_URL + username, value, times);
            } else if (o != null) {
                Integer count = (Integer) o;
                if (count >= 10) {
                    status = true;
                } else {
                    count++;
                    System.out.println("--------" + count);
                    redisUtil.lUpdateIndex(Constant.USER_REDIS_URL + username, 0, count);
                }
            }

        }
        return status;
    }

    private boolean checkTime(String startDate, String endDate) {
        Date nowDate = new Date();
        if (nowDate.getTime() > DateUtils.strToDate(startDate).getTime() && nowDate.getTime() < DateUtils.strToDate(endDate).getTime()) {
            return true;
        } else {
            return false;
        }
    }

    private boolean checkCsrfToken(HttpServletRequest request){
        boolean status = false;
        String referer = request.getHeader(REFERER);
        if(serviceCsrfUrl.equals(referer)){
            status = true;
        }
        return status;
    }
}
