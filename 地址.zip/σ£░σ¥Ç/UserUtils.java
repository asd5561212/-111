package com.panasonic.iotair.common;

import com.panasonic.iotair.bean.CurrentUser;
import org.springframework.beans.BeanUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import com.panasonic.iotair.bean.User;

/**
 * Created by liang on 2019/09/26.
 */
public class UserUtils {

    public static User getCurrentUser() {
        return (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }

    public static CurrentUser getRequestCurrentUser() {
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        CurrentUser currentUser = new CurrentUser();
        BeanUtils.copyProperties(user, currentUser);
        return currentUser;
    }
}
