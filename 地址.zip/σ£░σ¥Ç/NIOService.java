package com.panasonic.iotair.service;

import com.panasonic.iotair.common.NIOServer;

/**
 * @author tao
 * @version 1.0
 * @date 7/4/2020 下午3:28
 */
public class NIOService {


    public static void main(String[] args) {
        NIOServer.selector();
    }
}
