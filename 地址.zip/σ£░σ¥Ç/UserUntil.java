package com.panasonic.iotair.common;

import com.panasonic.iotair.bean.User;

/**
 * @author tao
 * @version 1.0
 * @date 27/3/2020 上午8:30
 */
public class UserUntil {


      private static ThreadLocal<User> threadLocal = new ThreadLocal<User>();


      public static User getCurrUser(){
          return threadLocal.get();
      }


      public static void setUser(User user){
          threadLocal.set(user);
      }

}
