package com.panasonic.iotair.service;

import com.alibaba.dubbo.config.annotation.Service;
import com.panasonic.iotair.api.UserServiceApi;
import com.panasonic.iotair.bean.RespBean;
import com.panasonic.iotair.common.RequestBean;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

/**
 * @author tao
 * @version 1.0
 * @date 19/3/2020 下午4:47
 */
@Component
@Service
public class UserService implements UserServiceApi {


    public void addCurrUser(RequestBean request) {
        System.out.println("username is " + request.getCurrentUser().getUsername());
    }
}
