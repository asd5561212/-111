package com.panasonic.iotair.common;

import com.panasonic.iotair.common.RequestBean;
import com.panasonic.iotair.common.UserUtils;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * @author tao
 * @version 1.0
 * @date 23/3/2020 下午4:44
 */
public class RPCRequest {

    private RPCRequest(){

    }

    public static RequestBean newInstance(Object param) {
        RequestBean request = new RequestBean(UserUtils.getRequestCurrentUser());
        request.setParameter(param);
        return request;
    }

    public static RequestBean newInstance() {
        RequestBean request = new RequestBean(UserUtils.getRequestCurrentUser());
        return request;
    }
}
